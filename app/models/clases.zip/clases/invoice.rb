class Invoice < ApplicationRecord
end