class Reservation < ApplicationRecord
end