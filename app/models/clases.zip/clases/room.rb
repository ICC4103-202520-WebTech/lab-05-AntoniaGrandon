class Room < ApplicationRecord
end