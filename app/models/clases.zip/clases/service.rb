class Service < ApplicationRecord
end