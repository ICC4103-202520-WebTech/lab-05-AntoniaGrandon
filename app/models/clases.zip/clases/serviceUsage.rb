class ServiceUsage < ApplicationRecord
end