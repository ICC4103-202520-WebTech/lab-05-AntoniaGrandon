class Guest < ApplicationRecord
end